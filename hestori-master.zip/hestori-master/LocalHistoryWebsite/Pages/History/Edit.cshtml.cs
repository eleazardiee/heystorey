using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LocalHistoryWebsite.Pages.History
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
